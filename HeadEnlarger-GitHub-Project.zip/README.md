# Head Enlarger

Minimal Android launcher for Standoff 2.

## What it does
- Opens Standoff 2 when the **BAŞLAT** button is tapped.
- Shows a clean, minimal interface.
- Does **not** modify game files, player models, hitboxes, aim, or gameplay.

## Build
1. Open this folder in Android Studio.
2. Allow Gradle sync to finish.
3. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. Find the APK under `app/build/outputs/apk/debug/`.

## Requirements
- Android Studio with Android SDK 35 installed.
- JDK 17.

## GitHub
Create a new GitHub repository and upload the contents of this folder.
